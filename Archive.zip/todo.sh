#!/usr/bin/env bash

node todo.js "$@"
